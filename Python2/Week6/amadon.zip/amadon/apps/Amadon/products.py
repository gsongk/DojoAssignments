items = [
    {
        "id": 1,
        "name": "Dojo T-Shirt",
        "price": 19.99,
    },
    {
        "id": 2,
        "name": "Dojo Sweater",
        "price": 29.99
    },
    {
        "id": 3,
        "name": "Dojo Cup",
        "price": 4.99
    },
    {
        "id": 4,
        "name": "Algorithm Book",
        "price": 49.99
    }
]
