using AjaxNotes.Models;

namespace AjaxNotes.Factories
{
    public interface IFactory<T> where T : BaseEntity { }
}