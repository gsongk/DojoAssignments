namespace AjaxNotes.Models
{
    public abstract class BaseEntity { }
}