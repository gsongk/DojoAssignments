using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DojoLeague.Models
{
    public class MySqlOptions
    {
        public string DefaultConnection { get; set; }
    }
}